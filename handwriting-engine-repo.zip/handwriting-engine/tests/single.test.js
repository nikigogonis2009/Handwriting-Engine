'use strict';
const test = require('node:test');
const assert = require('node:assert');
const { buildSingle } = require('../scripts/build-single');

test('single-page build inlines every stylesheet and script', () => {
  const html = buildSingle();
  assert.ok(!/<script src=/.test(html), 'no external scripts left');
  assert.ok(!/<link rel="stylesheet"/.test(html), 'no external stylesheet left');
  assert.ok(html.includes('HW_APP'), 'app code is inlined');
});
