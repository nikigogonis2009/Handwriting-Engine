#!/usr/bin/env node
// Inlines styles.css and every src/*.js script into one self-contained page, dist/handwriting-engine.html.
// That single file can be published as a claude.ai artifact (or hosted anywhere) and opened on the iPad.
'use strict';
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');

function buildSingle() {
  let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
  const css = fs.readFileSync(path.join(root, 'styles.css'), 'utf8');
  html = html.replace('<link rel="stylesheet" href="styles.css">', () => '<style>\n' + css + '\n</style>');
  html = html.replace(/<script src="([^"]+)"><\/script>/g, (_, file) => {
    // a literal "</script" inside the code would end the inline tag early
    const js = fs.readFileSync(path.join(root, file), 'utf8').replace(/<\/script/gi, '<\\/script');
    return '<script>\n' + js + '\n</script>';
  });
  return html;
}

if (require.main === module) {
  const out = path.join(root, 'dist', 'handwriting-engine.html');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, buildSingle());
  console.log('Wrote ' + path.relative(root, out));
}

module.exports = { buildSingle };
